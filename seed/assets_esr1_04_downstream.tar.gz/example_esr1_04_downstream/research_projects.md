# 10 Research Projects — ESR1 Knockdown Transcriptomic Landscape in Breast Cancer

**Dataset**: GSE153250 (MCF-7 cells, siESR1 vs siNT, n=6 per group)  
**Pipeline**: DESeq2 → ORA (clusterProfiler + Enrichr GMTs) → GSEA (fgsea, pre-ranked by Wald statistic)  
**Date**: 2025-08-04

---

## Project 1: TNFα/NF-κB Signaling as a Therapeutic Vulnerability in Endocrine-Resistant Breast Cancer

### Core Findings / Evidence Basis
- **TNFα/NF-κB is the #1 upregulated Hallmark pathway** in ESR1 knockdown cells:
  - GSEA: NES = +2.03, padj = 5.1×10⁻⁸ (3rd most significant pathway overall)
  - ORA: 84 genes enriched, padj = 6.4×10⁻¹³ (most significant ORA term across all libraries)
- Key upregulated NF-κB target genes include: *TNFAIP3* (A20), *NFKBIA* (IκBα), *NFKB2* (p100/p52), *RELB*, *JUNB*, *EGR1*, *IL6*, *CCL2*, *CXCL8*, *ICAM1*, *BIRC3*
- IL-6/JAK/STAT3 (NES = +1.44), Inflammatory Response (NES = +1.45), and Interferon Gamma Response (NES = +1.49) are also significantly upregulated, indicating a broad inflammatory program

### Scientific Question
Does ESR1 loss create a therapeutically exploitable dependency on NF-κB-mediated inflammatory signaling? Specifically, are ESR1-depleted breast cancer cells selectively sensitive to NF-κB pathway inhibitors (e.g., IKKβ inhibitors, proteasome inhibitors) compared to ESR1-intact cells?

### Clinical Significance
- Endocrine resistance (tamoxifen, aromatase inhibitors) occurs in ~30–50% of ER+ breast cancer patients and is a leading cause of breast cancer mortality
- ESR1 mutations (e.g., Y537S, D538G) are found in ~30% of metastatic ER+ breast cancers after aromatase inhibitor therapy and confer constitutive, ligand-independent activity or altered transcriptional programs
- If ESR1 loss or mutation creates NF-κB dependency, existing clinical-grade NF-κB inhibitors (bortezomib, ixazomib) or novel IKKβ inhibitors (e.g., BMS-345541, IMD-0354) could be rapidly repurposed
- This would provide a biomarker-stratified (ESR1-low/mutant) therapeutic strategy

### Study Design
**Phase 1 — In vitro validation (6 months):**
- CRISPR/Cas9 ESR1 knockout and doxycycline-inducible ESR1 knockdown in MCF-7, T47D, and ZR-75-1 cells
- Dose-response curves for IKKβ inhibitors (BMS-345541, IMD-0354, TPCA-1), proteasome inhibitors (bortezomib, carfilzomib), and NF-κB decoy oligonucleotides
- Measure apoptosis (Annexin V/PI, cleaved caspase-3), proliferation (EdU, colony formation), and NF-κB activity (p65 nuclear translocation, NF-κB luciferase reporter)
- RNA-seq of ESR1-KD cells ± IKKβ inhibitor to identify NF-κB-dependent transcriptional programs

**Phase 2 — Mechanistic dissection (6 months):**
- ChIP-seq for p65/RELA and histone marks (H3K27ac) in ESR1-intact vs ESR1-KD cells to map gained NF-κB binding sites
- Co-immunoprecipitation to test whether ESR1 physically interacts with NF-κB components
- Cytokine array profiling of conditioned media to identify paracrine factors (IL-6, CCL2, CXCL8)

**Phase 3 — In vivo proof-of-concept (12 months):**
- MCF-7 xenografts with inducible ESR1 shRNA ± IKKβ inhibitor treatment
- Tumor growth, metastasis, and immune infiltration (IHC, flow cytometry) assessment

### Key Highlights / Novelty
- **Conceptual advance**: Reframes NF-κB activation after ESR1 loss not as a bystander effect but as a *targetable vulnerability* — a synthetic essentiality created by loss of ESR1's repressive function
- **Therapeutic innovation**: Repurposing clinically approved NF-κB pathway drugs for endocrine-resistant breast cancer, with a clear biomarker (ESR1 status) for patient stratification
- **Mechanistic depth**: Genome-wide mapping of the ESR1→NF-κB axis through integrated RNA-seq and ChIP-seq, revealing *de novo* enhancer activation

---

## Project 2: p53 Pathway Reactivation as a Synthetic Lethal Partner of ESR1 Loss

### Core Findings / Evidence Basis
- **p53 pathway is strongly upregulated** after ESR1 KD:
  - GSEA: NES = +1.80, padj = 1.8×10⁻⁵
  - ORA: 75 genes enriched, padj = 1.8×10⁻⁶
- Key upregulated p53 targets: *CDKN1A* (p21), *BAX*, *GADD45A*, *TP53I3*, *TRIAP1*, *SERPINE1*, *BTG2*, *RRAD*, *FDXR*
- Apoptosis pathway also significantly upregulated (NES = +1.58, ORA 53 genes)
- Cell cycle pathways (E2F Targets NES = −1.68, G2-M Checkpoint NES = −1.65) are suppressed — consistent with p53-mediated cell cycle arrest

### Scientific Question
Is the p53 pathway functionally activated (not merely transcriptionally induced) after ESR1 loss, and does this create a synthetic lethal relationship that can be exploited by further p53-activating therapies (MDM2 inhibitors, e.g., nutlin-3a, idasanutlin)?

### Clinical Significance
- p53 is wild-type in MCF-7 cells and in ~70% of luminal ER+ breast cancers — this pathway is intact and druggable
- MDM2 inhibitors (nutlin-3a/RG7112, idasanutlin/RG7388, AMG-232) have shown clinical activity in hematologic malignancies but limited single-agent activity in solid tumors
- Combining MDM2 inhibition with endocrine therapy (or exploiting ESR1 loss) could provide a genotype-selective therapeutic strategy
- p53 activation + cell cycle arrest may synergize with CDK4/6 inhibitors already used in ER+ breast cancer

### Study Design
**Phase 1 — p53 functional validation (4 months):**
- ESR1 KD/CRISPR-KO in MCF-7 (p53 WT), T47D (p53 mutant L194F), and BT-474 (p53 mutant E285K) to test p53-dependence
- p53 knockout in MCF-7 ESR1-KD background; compare RNA-seq to determine which upregulated genes are truly p53-dependent
- Assess p53 protein stability, phosphorylation (Ser15, Ser20), and transcriptional activity (p53 luciferase reporter, p21 protein)

**Phase 2 — Pharmacological synergy (6 months):**
- Combination index (Chou-Talalay) for MDM2 inhibitors + fulvestrant or tamoxifen in ER+ cell lines
- Dose-response in isogenic ESR1-WT vs ESR1-KO lines
- Long-term colony formation assays and 3D organoid models

**Phase 3 — Mechanistic insight (6 months):**
- p53 ChIP-seq in ESR1-intact vs ESR1-KD cells to map differential p53 binding
- Determine whether ESR1 directly represses p53 target genes at the chromatin level (ERα ChIP-seq comparison)
- Test whether ESR1 and p53 compete for shared cofactors (e.g., p300/CBP)

### Key Highlights / Novelty
- **First systematic demonstration** that ESR1 loss leads to functional p53 pathway activation (not just transcriptional correlation)
- **Therapeutic hypothesis**: MDM2 inhibitors may be selectively effective in ESR1-low or endocrine-resistant breast cancers
- **Patient stratification**: p53 wild-type (70% of ER+ cancers) + ESR1-low/mutant as a dual biomarker

---

## Project 3: The ESR1–Notch Axis in Luminal-to-Basal Plasticity and EMT

### Core Findings / Evidence Basis
- **Notch signaling**: GSEA NES = +1.92, padj = 1.3×10⁻³; ORA: 15/31 Notch target genes enriched
- **EMT program**: GSEA NES = +1.38, padj = 3.0×10⁻²; ORA: 59 genes enriched (padj = 3.8×10⁻⁴)
- **Apical Junction remodeling**: NES = +1.58, padj = 3.9×10⁻³
- Upregulated Notch/EMT genes include: *JAG1* (Notch ligand), *HES1*, *NOTCH1*, *SNAI2* (Slug), *FN1*, *TGFBI*, *CCN1*, *CCN2*, *VEGFA*, *WNT5A*, *CDH2* (N-cadherin)
- ESR1 ChIP-seq (ENCODE T47D) gene set is significantly enriched among downregulated genes (NES = −1.82), while ESR1 MCF-7 is enriched (NES positive for some libraries), suggesting ESR1 directly suppresses Notch/EMT components

### Scientific Question
Does ESR1 loss activate Notch-driven epithelial-to-mesenchymal transition (EMT) as a mechanism to increase cellular plasticity, invasion, and metastatic potential in ER+ breast cancer cells?

### Clinical Significance
- EMT and increased plasticity are associated with metastasis, drug resistance, and cancer stem cell (CSC) properties
- Notch can be targeted pharmacologically with gamma-secretase inhibitors (GSIs: DAPT, RO4929097, MK-0752) or DLL4-blocking antibodies (demcizumab)
- Understanding the ESR1–Notch–EMT axis could identify patients at risk for endocrine therapy-induced invasion
- JAG1 expression (significantly upregulated) is a potential biomarker and therapeutic target

### Study Design
**Phase 1 — Phenotypic characterization (6 months):**
- ESR1 KD/KO in MCF-7 and T47D; assess: (a) morphology (phase-contrast, phalloidin staining), (b) migration/invasion (Boyden chamber, wound healing), (c) EMT markers (E-cadherin, N-cadherin, vimentin, ZEB1/2, SNAI1/2 by western blot and IF)
- Flow cytometry for CD44/CD24 (breast CSC markers) and ALDH activity

**Phase 2 — Notch pathway dissection (6 months):**
- Notch reporter assays (CSL/RBP-J luciferase) after ESR1 KD
- siRNA knockdown of JAG1, NOTCH1, HES1, or SNAI2 in ESR1-KD background to test rescue of EMT phenotypes
- GSI treatment (DAPT, RO4929097) ± fulvestrant; measure invasion and CSC markers
- ChIP-seq for NICD (cleaved Notch1 intracellular domain) and H3K27ac in ESR1-intact vs ESR1-KD cells

**Phase 3 — In vivo metastasis (12 months):**
- Tail vein injection of ESR1-KD vs control MCF-7-luciferase cells in NSG mice
- Notch inhibitor treatment; bioluminescence monitoring of metastatic burden
- IHC for EMT markers and Notch targets in lung/liver metastases

### Key Highlights / Novelty
- **Novel mechanistic link**: Direct evidence that ESR1 transcriptionally represses Notch ligands (JAG1) and Notch targets (HES1), providing a molecular explanation for EMT activation upon endocrine therapy
- **Clinical implication**: GSIs may prevent or reverse endocrine therapy-induced invasion
- **Biomarker**: JAG1/HES1 as predictive markers of invasive potential in ESR1-low tumors

---

## Project 4: EPHA2 — A Novel Driver and Therapeutic Target in ESR1-Deficient Breast Cancer

### Core Findings / Evidence Basis
- **EPHA2 is the #1 most significantly upregulated gene** in the entire dataset (log2FC = +2.74, padj ≈ 0, stat = 37.98)
- EPHA2 is a receptor tyrosine kinase (Ephrin type-A receptor 2) implicated in tumor invasion, angiogenesis, and drug resistance
- EPHA2 overexpression has been linked to poor prognosis in multiple cancers (breast, lung, glioblastoma, ovarian)
- The Ephrin-Eph signaling axis is druggable: small molecule inhibitors (dasatinib targets EPHA2), monoclonal antibodies (DS-8895a), and ADC approaches exist
- Among GSEA Reactome, "Signaling by Receptor Tyrosine Kinases" is significantly enriched (padj = 0.015), supporting broad RTK reprogramming

### Scientific Question
Is EPHA2 a functional driver of the aggressive phenotype associated with ESR1 loss, and can EPHA2-targeted therapies (dasatinib, anti-EPHA2 ADCs) selectively eliminate ESR1-deficient breast cancer cells?

### Clinical Significance
- EPHA2 is a surface receptor — highly druggable via small molecules, therapeutic antibodies, and antibody-drug conjugates (ADCs)
- DS-8895a (anti-EPHA2 ADC) and MEDI-547 (anti-EphA2 ADC) have entered clinical trials
- If EPHA2 is functionally important after ESR1 loss, it provides a targeted therapy option for endocrine-resistant disease
- EPHA2 overexpression could serve as a companion diagnostic biomarker

### Study Design
**Phase 1 — Functional validation (4 months):**
- siRNA/shRNA knockdown of EPHA2 in MCF-7 ESR1-KD cells; assess proliferation, apoptosis, migration, and invasion
- EPHA2 overexpression in ESR1-intact MCF-7/T47D; assess whether it phenocopies ESR1 loss
- Phospho-RTK array to map the broader RTK activation landscape after ESR1 KD

**Phase 2 — Pharmacological targeting (6 months):**
- Dose-response of dasatinib (multi-kinase inhibitor with EPHA2 activity), ALW-II-41-27 (EPHA2-selective inhibitor) in ESR1-KD vs control cells
- Anti-EPHA2 antibody treatment (functional blocking) in vitro
- 3D spheroid invasion assays with EPHA2 inhibition

**Phase 3 — Mechanism (6 months):**
- EPHA2 interactome (co-IP + mass spectrometry) in ESR1-KD vs intact cells
- Phosphoproteomics after EPHA2 activation/inhibition to identify downstream signaling (Akt, ERK, Src, FAK)
- EPHA2 ChIP-seq (indirectly via TF analysis) or EPHA2-proximal biotinylation (BioID/APEX) to map signaling complexes

**Phase 4 — In vivo (12 months):**
- MCF-7 ESR1-KD xenografts ± dasatinib or anti-EPHA2 ADC
- Patient-derived xenografts (PDX) of ESR1-mutant breast cancers

### Key Highlights / Novelty
- **First identification** of EPHA2 as a top-tier transcriptional target derepressed by ESR1 loss
- **Immediate translational potential**: Dasatinib (FDA-approved for CML/ALL) could be repurposed, and anti-EPHA2 ADCs are in clinical development
- **Companion biomarker**: EPHA2 IHC or serum EPHA2 levels as a stratification tool

---

## Project 5: Metabolic Reprogramming — From Estrogen-Driven Glycolysis to Alternative Fuel Dependence

### Core Findings / Evidence Basis
Multiple metabolic pathways are coordinately downregulated after ESR1 KD (GSEA):
- Glycolysis: NES = −1.53, padj = 5.2×10⁻³
- mTORC1 Signaling: NES = −1.48, padj = 7.5×10⁻³
- Cholesterol Homeostasis: NES = −1.24
- Fatty Acid Metabolism: NES = −1.18
- Oxidative Phosphorylation: NES = +1.21 (trending up)
- Steroid Biosynthesis (KEGG): NES = −1.94, padj = 6.3×10⁻³
- Purine Metabolism (KEGG): NES = −1.59, padj = 0.039

This suggests a profound metabolic switch: from anabolic/glycolytic (Warburg) metabolism driven by ESR1 to a catabolic/oxidative state.

### Scientific Question
Does ESR1 loss fundamentally rewire breast cancer cell metabolism, creating specific metabolic vulnerabilities (e.g., dependency on oxidative phosphorylation, fatty acid oxidation, or amino acid metabolism) that can be therapeutically targeted?

### Clinical Significance
- Metabolic reprogramming is a hallmark of cancer and a source of therapeutic targets
- OXPHOS inhibitors (metformin, IACS-010759, phenformin), fatty acid oxidation inhibitors (etomoxir, perhexiline), and glutaminase inhibitors (CB-839/telaglenastat) are in clinical development
- If ESR1-low cells switch from glycolysis to OXPHOS dependence, they may be selectively sensitive to OXPHOS inhibitors — a synthetic lethality approach
- Metabolic imaging (FDG-PET vs alternative tracers) could monitor this metabolic switch non-invasively

### Study Design
**Phase 1 — Metabolic profiling (6 months):**
- Seahorse XF analyzer: oxygen consumption rate (OCR, OXPHOS) and extracellular acidification rate (ECAR, glycolysis) in ESR1-KD vs control cells under basal and stressed conditions
- Steady-state metabolomics (LC-MS/MS) of central carbon metabolism (glycolysis, TCA cycle, PPP, amino acids)
- ¹³C-glucose and ¹³C-glutamine isotope tracing to map metabolic fluxes

**Phase 2 — Metabolic dependency screening (6 months):**
- CRISPR metabolic gene essentiality screen in ESR1-intact vs ESR1-KD isogenic cells
- Pharmacological profiling: dose-response of OXPHOS inhibitors, FAO inhibitors, glutaminase inhibitors, and AMPK activators
- Glucose deprivation and galactose/glutamine substitution experiments

**Phase 3 — Mechanism (4 months):**
- RNA-seq analysis of metabolic gene expression with integrated metabolomics (Mummichog pathway analysis)
- ChIP-seq for ERRα, PGC-1α, and NRF1 — master regulators of oxidative metabolism
- Determine whether ESR1 directly binds and regulates key metabolic genes (e.g., HK2, PKM, LDHA, ACLY, FASN)

**Phase 4 — In vivo validation (12 months):**
- MCF-7 ESR1-KD xenografts ± metformin or IACS-010759
- FDG-PET and alternative metabolic imaging (e.g., ¹⁸F-FAZA for hypoxia)

### Key Highlights / Novelty
- **First comprehensive metabolic flux analysis** of ESR1 loss in breast cancer
- **Therapeutic hypothesis**: ESR1-low tumors switch to OXPHOS dependence and become selectively sensitive to OXPHOS inhibitors
- **Clinical synergy**: Combining endocrine therapy (which may induce this switch) with metformin (already in breast cancer adjuvant trials)
- **Biomarker**: Metabolic gene signature to identify ESR1-low tumors that have undergone metabolic reprogramming

---

## Project 6: ECM Remodeling and Focal Adhesion — Mediators of Invasion After ESR1 Loss

### Core Findings / Evidence Basis
- **Focal Adhesion (KEGG)**: GSEA NES = +1.72, padj = 1.3×10⁻³; ORA: 65 genes enriched
- **Proteoglycans in Cancer (KEGG)**: ORA: 66 genes enriched, padj = 2.6×10⁻⁴
- **Extracellular Matrix Organization (Reactome)**: GSEA significant (padj = 3.9×10⁻³)
- **Degradation of the Extracellular Matrix (Reactome)**: GSEA padj = 0.013
- **Apical Junction (Hallmark)**: NES = +1.58
- **Integrin-mediated Signaling Pathway (GO BP)**: NES = +1.87
- Upregulated ECM/adhesion genes: *FN1*, *ITGAV*, *ITGB3*, *LAMB3*, *COL1A1*, *COL5A1*, *COL7A1*, *MMP9*, *TGFBI*, *CCN1*, *CCN2*, *SERPINE1*, *CDH2*
- Downregulated cell adhesion genes noted in 4,314 down DEGs

### Scientific Question
Does ESR1 loss drive a coordinated ECM remodeling program that promotes focal adhesion turnover, cytoskeletal reorganization, and 3D invasion, and can this be blocked by integrin or FAK inhibitors?

### Clinical Significance
- ECM stiffness and remodeling are physical determinants of breast cancer invasion and metastasis
- Focal adhesion kinase (FAK) inhibitors (defactinib/VS-6063, GSK2256098) have shown clinical activity in ovarian cancer and mesothelioma
- Integrin inhibitors (cilengitide, αvβ3/αvβ5 antagonist) have been tested in glioblastoma
- Anti-fibrotic agents (e.g., losartan, pirfenidone) could reduce ECM-driven invasion

### Study Design
**Phase 1 — ECM and adhesion phenotyping (6 months):**
- 3D Matrigel/collagen I invasion assays with defined matrix stiffness
- Live-cell imaging of focal adhesion dynamics (paxillin-GFP, zyxin-mCherry) in ESR1-KD vs control
- Traction force microscopy to measure cellular contractility
- Decellularized ECM from ESR1-KD vs control cells analyzed by mass spectrometry (matrisome)

**Phase 2 — Pharmacological intervention (6 months):**
- FAK inhibitors (defactinib, PF-573228), integrin blocking antibodies (anti-αvβ3, anti-α5β1), and Src inhibitors (dasatinib, saracatinib) in ESR1-KD cells
- 3D invasion and MMP activity (gelatin zymography, in situ zymography) after treatment

**Phase 3 — Mechanistic insight (6 months):**
- RNA-seq and ATAC-seq in ESR1-KD cells ± FAK inhibitor; identify FAK-dependent transcriptional programs
- Determine whether ESR1 directly represses ECM gene promoters/enhancers (ChIP-seq for ERα, H3K27ac)
- YAP/TAZ mechanotransduction assessment (nuclear translocation, TEAD reporter)

**Phase 4 — In vivo (12 months):**
- Orthotopic MCF-7 ESR1-KD xenografts ± FAK inhibitor; second harmonic generation (SHG) imaging of collagen architecture
- Circulating tumor cell (CTC) quantification

### Key Highlights / Novelty
- **Mechanistic concept**: ESR1 as a guardian of epithelial adhesion — its loss triggers a coordinated ECM-invasive program
- **Therapeutic innovation**: FAK inhibitors for preventing endocrine therapy-induced invasion (adjuvant setting with aromatase inhibitors)
- **Physical sciences integration**: Traction force microscopy and SHG imaging for quantitative, clinically translatable metrics

---

## Project 7: Systematic Mapping of the ESR1-Dependent and ESR1-Repressed Transcriptional Regulatory Network

### Core Findings / Evidence Basis
The ChEA 2022 and ENCODE TF ChIP-seq GSEA libraries provide an unprecedented view of TF network reorganization:
- **ChEA 2022 — Top TFs associated with upregulated genes** (programs activated after ESR1 KD): KDM2B (padj ≈ 0), TBX2 (padj ≈ 0), LXR (padj ≈ 0), SMC4 (padj ≈ 0), ELK3 (padj = 2.8×10⁻¹⁷), PPAR (padj = 1.4×10⁻¹³), BCOR (padj = 3.7×10⁻¹³)
- **ChEA 2022 — ESR1 programs** significantly associated with downregulated genes: ESR1 20056654 MCF-7 (NES = −1.49, padj = 9.9×10⁻⁶), ESR1 30970003 MCF-7 (NES = −1.42), ESR1 22217937 MCF-7 (NES = −1.73), ESR1 20079471 T-47D (NES = −1.69)
- **ENCODE TF — FOXM1 MCF-7**: NES = −2.06, padj = 6.5×10⁻⁷ (strongest ENCODE hit), suggesting FOXM1 is a major ESR1-cooperative TF
- **ENCODE TF — ESR1 T47D**: NES = −1.82, padj = 2.8×10⁻⁶
- Over 200 TFs show significant (padj < 0.05) enrichment in ChEA 2022, providing a rich resource for network reconstruction

### Scientific Question
Can we construct a comprehensive, experimentally-validated transcriptional regulatory network that explains the global transcriptomic response to ESR1 loss — identifying which TFs mediate ESR1's activating functions (lost after KD), which TFs are de-repressed, and how these networks are interconnected?

### Clinical Significance
- ESR1 itself is not directly druggable beyond existing endocrine therapies — but the TFs downstream of ESR1 (FOXM1, PPARγ, CREB1, KLF5, ELK3) are potentially druggable
- FOXM1 inhibitors (thiostrepton, FDI-6) are in preclinical development; PPARγ agonists (pioglitazone) are FDA-approved for diabetes
- A comprehensive TF network map would identify the most vulnerable nodes downstream of ESR1 loss
- This systems-level understanding could predict synergistic drug combinations

### Study Design
**Phase 1 — Network construction (6 months):**
- Integrate all ChEA 2022, ENCODE TF, and ENCODE Histone Modification GSEA results into a ranked TF network
- Weighted gene co-expression network analysis (WGCNA) of the full RNA-seq dataset
- ARACNe or GENIE3 to infer TF→target gene regulatory edges from the expression data alone
- Integrate with public ChIP-seq data (ReMap, CistromeDB) for ESR1, FOXM1, GATA3, and other relevant TFs in MCF-7

**Phase 2 — Experimental validation (8 months):**
- Select top 10–15 candidate TFs (5 "lost activators": FOXM1, MYB, GATA3; 5 "de-repressed": CREB1, ELK3, PPARγ, KLF5, TBX2; and 5 novel)
- siRNA knockdown of each TF in both ESR1-intact and ESR1-KD backgrounds
- RNA-seq after each TF knockdown (15 × 2 conditions = 30 RNA-seq libraries) to map regulons

**Phase 3 — Network integration (4 months):**
- Construct a directed TF→target gene network
- Identify feed-forward loops, feedback regulation, and convergent regulation
- Model the network's response to perturbations (ESR1 KD) and compare with experimental data
- Identify network bottlenecks — TFs that are both highly connected and differentially regulated

**Phase 4 — Translational validation (6 months):**
- Pharmacological inhibition of top 3 network bottleneck TFs in ESR1-KD cells
- Test synergy with fulvestrant in ESR1-intact cells

### Key Highlights / Novelty
- **Unprecedented resolution**: Combines ~700 TF ChIP-seq libraries with genome-wide expression data to produce the most comprehensive ESR1 regulatory network to date
- **Network medicine approach**: Identifying TF bottlenecks as new drug targets — moving beyond single-gene thinking
- **Resource generation**: A publicly available, experimentally validated TF network for the breast cancer research community
- **Predictive power**: The network could be used to predict which TFs drive endocrine resistance in patient tumors

---

## Project 8: GREB1 — A Master ESR1 Co-Regulator, Biomarker, and Functional Mediator

### Core Findings / Evidence Basis
- **GREB1 is the single most strongly downregulated gene** in the entire dataset: log2FC = −4.71, stat = −63.63, padj ≈ 0
- GREB1 (Growth Regulation by Estrogen in Breast Cancer 1) is a well-known estrogen-responsive gene, but its function remains poorly understood
- GREB1 is a component of both Estrogen Response Early (98 downregulated genes, padj ≈ 0) and Estrogen Response Late (96 genes, padj ≈ 0) gene sets
- GREB1 physically interacts with ERα and may function as a co-regulator or scaffolding protein
- GREB1 is also significantly downregulated in the "Estrogen-dependent Gene Expression" Reactome pathway (padj = 0.013)

### Scientific Question
What is the functional role of GREB1 in mediating ESR1's transcriptional program? Is GREB1 a necessary cofactor for ERα genomic binding, or does it function downstream as an effector of the estrogen response? Can GREB1 serve as a superior biomarker for ESR1 activity compared to ERα IHC?

### Clinical Significance
- GREB1 expression is more tightly correlated with ESR1 activity than ERα itself; it may be a better pharmacodynamic biomarker for endocrine therapy
- If GREB1 is a functional mediator rather than a passive target, it could be a therapeutic target itself
- GREB1 downregulation may be a more sensitive and specific readout of effective endocrine therapy than Ki-67 or ERα IHC
- GREB1 expression is lost early in endocrine resistance — it may serve as a biomarker of emerging resistance

### Study Design
**Phase 1 — GREB1 functional characterization (6 months):**
- GREB1 CRISPR-KO and GREB1 overexpression in MCF-7 and T47D cells
- RNA-seq of GREB1-KO cells ± estrogen treatment; compare with ESR1-KD transcriptome to determine what fraction of ESR1's effects are GREB1-dependent
- GREB1 interactome: co-IP + mass spectrometry (GREB1-FLAG) to identify protein partners
- GREB1 subcellular localization (IF, cell fractionation) and dynamics after estrogen treatment

**Phase 2 — GREB1 and ERα genomic interaction (6 months):**
- ERα ChIP-seq in GREB1-KO vs GREB1-WT cells to test whether GREB1 is required for ERα genomic binding
- GREB1 ChIP-seq (if possible) or CUT&RUN to identify GREB1 genomic binding sites
- HiChIP or Hi-C in GREB1-KO cells to assess whether GREB1 mediates ERα-dependent chromatin looping

**Phase 3 — GREB1 as a biomarker (6 months):**
- GREB1 IHC in a cohort of primary ER+ breast cancers (n ≥ 200) with long-term outcome data
- Correlation with ERα IHC, PR, HER2, Ki-67, Oncotype DX, and distant recurrence-free survival
- GREB1 mRNA in serial biopsies from patients on neoadjuvant endocrine therapy — comparison with Ki-67 for predicting response

**Phase 4 — Structural biology (12 months):**
- Cryo-EM or X-ray crystallography of GREB1-ERα complex
- Identify GREB1 domains required for ERα interaction and transcriptional co-regulation
- Develop GREB1-ERα interaction inhibitors (peptidomimetics or small molecules)

### Key Highlights / Novelty
- **Functional dissection** of one of the most estrogen-responsive genes in the human genome
- **Biomarker innovation**: GREB1 as a superior companion diagnostic for endocrine therapy — potentially more dynamic and specific than ERα IHC
- **Structural biology + drug discovery**: GREB1-ERα interface as a novel therapeutic target distinct from the ERα ligand-binding domain

---

## Project 9: Inflammatory Cytokine Network — ESR1 Loss Reshaping the Tumor Immune Microenvironment

### Core Findings / Evidence Basis
Multiple inflammatory/immune pathways are activated after ESR1 KD:
- **IL-6/JAK/STAT3 Signaling**: NES = +1.44, padj = 4.8×10⁻²; ORA: 29 genes enriched
- **Interferon Gamma Response**: NES = +1.49, padj = 6.9×10⁻³; ORA: 54 genes enriched
- **Inflammatory Response**: NES = +1.45, padj = 0.024; ORA: 49 genes enriched
- **Interferon Alpha Response**: NES = +1.34, padj = 0.082; ORA: 54 genes enriched (in larger analysis)
- **Complement**: NES = +1.33, padj = 0.050
- **TNFα/NF-κB**: NES = +2.03 (see Project 1)
- Key upregulated cytokines/chemokines: *IL6*, *CCL2*, *CCL20*, *CXCL8*, *TNF*, *LIF*, *CSF1*, *CCL22*, *CXCL12*, *VEGFA*
- Key upregulated immune signaling components: *JAK2*, *TYK2*, *STAT3*, *STAT5A*, *IRF1*, *IRF8*, *NFKB2*, *RELB*, *CIITA*, *TAP1*, *PSMB9*, *B2M*

### Scientific Question
Does ESR1 loss in tumor cells autonomously drive a pro-inflammatory cytokine secretion program that reshapes the tumor immune microenvironment (TIME), potentially converting an immune-excluded ("cold") ER+ tumor into an immune-inflamed ("hot") tumor?

### Clinical Significance
- ER+ breast cancers are typically immunologically "cold" with low TILs, low PD-L1, and poor response to immune checkpoint inhibitors (ICIs)
- If ESR1 loss/inhibition induces a pro-inflammatory secretome, this could paradoxically make tumors more responsive to immunotherapy
- The timing of endocrine therapy relative to immunotherapy could be critical — ESR1 degradation (fulvestrant) or inhibition (aromatase inhibitors) may prime the TIME for ICI response
- Alternatively, the inflammatory secretome may promote tumor progression through immune evasion (MDSC recruitment, Treg induction) — requiring careful dissection

### Study Design
**Phase 1 — Secretome and immune profiling (6 months):**
- Multiplex cytokine/chemokine profiling (Luminex, Olink) of conditioned media from ESR1-KD vs control MCF-7, T47D, and ZR-75-1 cells
- Co-culture assays: monocyte-derived macrophages, CD8+ T cells, and NK cells with ESR1-KD vs control tumor cells
  - Macrophage polarization (M1: CD80/CD86, M2: CD163/CD206)
  - T cell activation (CD69, IFN-γ, granzyme B)
  - NK cell cytotoxicity (calcein-AM release)

**Phase 2 — In vivo immune contexture (12 months):**
- Syngeneic ER+ mouse model (if available) or humanized NSG mouse model with MCF-7 ESR1-KD xenografts
- Multiplex IHC (CODEX, MIBI) or mass cytometry (CyTOF) for comprehensive immune profiling
- Flow cytometry: CD8+ T cells, CD4+ T cells (Th1/Th2/Treg), NK cells, MDSCs, tumor-associated macrophages, dendritic cells

**Phase 3 — Immune checkpoint combination (6 months):**
- MCF-7 ESR1-KD xenografts ± anti-PD-L1 or anti-CTLA-4
- Combination of fulvestrant (ESR1 degrader) + anti-PD-L1 — timing optimization (concurrent vs sequential)
- Measure TILs, PD-L1 expression (IHC), and T cell clonality (TCR-seq)

**Phase 4 — Human translation (12 months):**
- Spatial transcriptomics (Visium, MERFISH) of paired pre- and on-treatment biopsies from ER+ breast cancer patients receiving neoadjuvant endocrine therapy
- Correlate ESR1 activity score with immune infiltration signatures

### Key Highlights / Novelty
- **Provocative hypothesis**: Endocrine therapy may convert immunologically "cold" ER+ tumors to "hot" — providing a rationale for ICI + endocrine therapy combinations currently being tested in trials (NCT02971748, NCT03051659)
- **Cautionary finding**: If the inflammatory secretome is pro-tumorigenic, concurrent anti-inflammatory strategies may be needed
- **Spatial resolution**: Spatial transcriptomics will reveal whether immune infiltration occurs specifically in ESR1-low tumor regions

---

## Project 10: Translational Suppression — A Therapeutic Window for ESR1-Deficient Breast Cancer

### Core Findings / Evidence Basis
Translation and ribosome biogenesis are the most strongly suppressed programs after ESR1 KD:
- **Ribosome (KEGG)**: NES = −2.03, padj = 7.7×10⁻⁶ — #1 most significant KEGG pathway
- **Translation (GO BP)**: NES = −1.80, padj = 1.3×10⁻³ — #1 most significant GO BP pathway
- **Peptide Chain Elongation (Reactome)**: NES = −1.90, padj = 5.3×10⁻³
- **Eukaryotic Translation Termination (Reactome)**: NES = −1.87, padj = 5.3×10⁻³
- **Viral mRNA Translation (Reactome)**: NES = −1.89, padj = 5.7×10⁻³
- **Nonsense Mediated Decay (Reactome)**: NES = −1.86, padj = 5.7×10⁻³
- **Eukaryotic Translation Elongation (Reactome)**: NES = −1.84, padj = 5.7×10⁻³
- **Mitochondrial Translation (Reactome)**: NES = −1.71, padj = 0.020
- **Protein Biosynthetic Process (GO BP)**: NES = −1.63, padj = 0.062
- **SRP-dependent Cotranslational Protein Targeting (Reactome)**: NES = −1.64, padj = 0.033
- **Formation of a Pool of Free 40S Subunits (Reactome)**: NES = −1.77, padj = 0.013

This is a coordinated suppression of ribosomal protein genes, translation initiation/elongation factors, and tRNA synthetases — essentially a shutdown of the translational machinery. At the same time, mTORC1 (NES = −1.48) and MYC Targets V1 (NES = −1.40) are suppressed, consistent with loss of growth signaling upstream of ribosome biogenesis.

### Scientific Question
Does ESR1 loss induce a state of reduced translational capacity that creates a therapeutic vulnerability — specifically, are ESR1-deficient cells hypersensitive to translation inhibitors (e.g., homoharringtonine/omacetaxine, rocaglates, or mTOR inhibitors) because they are already operating at the lower limit of sustainable protein synthesis?

### Clinical Significance
- Translation inhibitors are FDA-approved: omacetaxine mepesuccinate (Synribo®) for CML; everolimus (mTORC1 inhibitor) is already approved for ER+ breast cancer (BOLERO-2 trial)
- Rocaglates (e.g., silvestrol, eFT508/tomivosertib) are novel translation inhibitors targeting eIF4A in clinical trials
- Ribosome biogenesis inhibitors (e.g., CX-5461, BMH-21 — RNA Pol I inhibitors) are in Phase I/II trials
- If ESR1 loss increases sensitivity to translation inhibition, these drugs could be more effective in endocrine-resistant disease
- This represents a non-hormonal therapeutic strategy for ESR1-mutant or ESR1-low breast cancer

### Study Design
**Phase 1 — Translational profiling (6 months):**
- Polysome profiling (sucrose gradient ultracentrifugation) to measure global translation (80S monosomes vs polysomes) in ESR1-KD vs control cells
- Puromycin incorporation assay (SUnSET) to measure *de novo* protein synthesis rates
- Ribo-seq (ribosome footprinting) in ESR1-KD vs control cells to identify transcripts with altered translational efficiency
- O-propargyl-puromycin (OPP) labeling and click chemistry for nascent protein imaging

**Phase 2 — Drug sensitivity profiling (6 months):**
- Dose-response of translation inhibitors in ESR1-intact vs ESR1-KD isogenic pairs:
  - Omacetaxine (ribosome inhibitor; FDA-approved)
  - Silvestrol / eFT508 (eIF4A helicase inhibitors)
  - Everolimus (mTORC1 → 4E-BP → cap-dependent translation)
  - CX-5461 (RNA Pol I inhibitor; ribosome biogenesis)
  - Rapalink-1 (mTORC1/2 inhibitor)
- Synergy testing with fulvestrant
- Clonogenic survival and apoptosis after combined ESR1 degradation + translation inhibition

**Phase 3 — Mechanistic dissection (6 months):**
- Western blot for translation regulators: phospho-4E-BP1, phospho-S6, phospho-eIF2α, eIF4E, eIF4G
- mTORC1 activity: phospho-p70 S6K, phospho-S6, phospho-4E-BP1
- Identify whether ESR1 regulates ribosomal protein gene transcription directly (ChIP-seq) or indirectly through MYC/mTORC1
- Test whether MYC overexpression rescues translation suppression in ESR1-KD cells

**Phase 4 — In vivo (12 months):**
- MCF-7 ESR1-KD xenografts ± omacetaxine or eFT508
- PDX models of ESR1-mutant breast cancer treated with translation inhibitors
- Pharmacodynamic biomarkers: phospho-S6 IHC, Ki-67, and polysome/monosome ratio in tumor tissue

### Key Highlights / Novelty
- **First demonstration** that ESR1 is a master regulator of the translational machinery — not just transcription
- **Therapeutic concept**: "Translational addiction" — ESR1-deficient cells have reduced translational reserves and are closer to the minimum threshold for viability, making them hypersensitive to further translation inhibition
- **Clinical feasibility**: Multiple FDA-approved or late-stage clinical translation inhibitors available for rapid repurposing
- **Ribo-seq resource**: First genome-wide translational efficiency map in the context of ESR1 loss

---

## Summary Table

| # | Project Title | Primary Pathway | Translational Strategy | Key Marker |
|---|---|---|---|---|
| 1 | TNFα/NF-κB as Therapeutic Vulnerability | NF-κB | IKKβ inhibitors, bortezomib | NFKB2, RELB, IL6 |
| 2 | p53 Synthetic Lethality | p53 | MDM2 inhibitors | CDKN1A, BAX |
| 3 | ESR1–Notch–EMT Axis | Notch, EMT | γ-secretase inhibitors | JAG1, HES1, SNAI2 |
| 4 | EPHA2 Driver in ESR1-Deficient BC | RTK signaling | Dasatinib, anti-EPHA2 ADC | EPHA2 |
| 5 | Metabolic Reprogramming | Glycolysis, OXPHOS | OXPHOS inhibitors | HK2, metabolic flux |
| 6 | ECM Remodeling & Invasion | Focal Adhesion | FAK inhibitors | FN1, ITGAV, MMP9 |
| 7 | ESR1 TF Regulatory Network | Multiple TFs | TF network bottlenecks | FOXM1, CREB1, PPARγ |
| 8 | GREB1 Co-Regulator & Biomarker | Estrogen Response | GREB1-ERα interface | GREB1 |
| 9 | Inflammatory TIME Remodeling | Cytokine/JAK-STAT | ICIs + endocrine therapy | IL6, CCL2, CXCL8 |
| 10 | Translational Suppression Window | Ribosome/Translation | Omacetaxine, eFT508 | Phospho-S6, polysomes |

## Data Availability
All raw and processed data supporting these projects are available in:
- DEG results: `results/tables/DESeq2_full_results.csv`
- GSEA results: `results/tables/GSEA_*.csv` (8 libraries, 4,725 total pathways tested)
- ORA results: `results/tables/ORA_*.csv` (12 files across 4 libraries)
- Ranked gene list: `results/tables/ranked_genes.tsv`
- Full pipeline documentation: `analysis/DEG/README.md`, `analysis/GSEA/README.md`, `analysis/enrichment/README.md`

## Software & Versions
| Tool | Version | Purpose |
|---|---|---|
| R | 4.4.2 (2024-10-31) | Statistical computing |
| DESeq2 | 1.46.0 | Differential expression |
| fgsea | 1.32.4 | Gene set enrichment |
| clusterProfiler | 4.14.6 | ORA, GMT parsing |
| org.Hs.eg.db | 3.20.0 | Gene annotation |
| Enrichr GMTs | 2025-08-03 | Gene set databases (218 libraries) |

---

*Generated by wisp-science on 2025-08-04 from the GSE153250 ESR1 knockdown transcriptome analysis pipeline*
